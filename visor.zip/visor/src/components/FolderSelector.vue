<template>
  <!-- Componente removido: La ruta de backup ahora se configura automáticamente desde .env -->
  <!-- Ver CONFIGURACION-RED.md para más información -->
</template>

<script setup lang="ts">
// Este componente ya no se usa.
// La configuración de rutas ahora es automática via .env
// Ver: electron/main.js -> findBackupFolder()
</script>
